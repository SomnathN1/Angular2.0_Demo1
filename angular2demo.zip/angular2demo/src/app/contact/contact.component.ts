import { Component, OnInit } from '@angular/core';

@Component({
	templateUrl: 'contact.component.html'
})
export class ContactComponent implements OnInit {
	constructor() {}

	ngOnInit() {
		
	}
}