# Angular 2 CRUD Demo

## Setup 

```
npm i
```

## Run Application

```
ng serve
// now browse http://localhost:4200
```